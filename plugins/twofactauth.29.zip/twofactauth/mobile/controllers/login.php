<?php

 class TWOFACTAUTH_MCTRL_Login extends OW_MobileActionController
 { 
	
	public function verify($param)
	{
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();

		$form = new Form('twofactauthverify');
		
		$fieldCode = new TextField('code');
		$fieldCode->setLabel("Code");
		$fieldCode->setRequired();
        $fieldCode->setHasInvitation(true);
		$fieldCode->addValidator(new IntValidator());
		$fieldCode->addAttribute("type", "number");
		$form->addElement($fieldCode);
		
		$fieldSave = new CheckboxField('save');
		$fieldSave->setLabel("Save");
		$form->addElement($fieldSave);
		
		$submit = new Submit('send');
		$submit->setValue(OW::getLanguage()->text('twofactauth', 'verify_send'));
		$form->addElement($submit);
		
		$this->addForm($form);

        
        OW::getDocument()->getMasterPage()->setTemplate(OW::getThemeManager()->getMasterPageTemplate('mobile_blank'));

		
		if ( OW::getRequest()->isPost() && $form->isValid($_POST) )
		{
			$data = $form->getValues();
            $gen = new TWOFACTAUTH_CLASS_SecretsGen();
			$result = TWOFACTAUTH_BOL_Service::getInstance()->getSecret();
			if($gen->verifyCode($result['secret'], $data['code'], 1)){
				OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'login_success'));
				OW::getSession()->set('twofactauth.logged', true);
                $response = OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_logsalt` WHERE userId = ".OW::getUser()->getId());
                $logsalt = "";
                if(empty($response)) {
                    $chars = "012346789ABCDEFGHIJKLMNOPQRSTUVWXYZ#!$&%";
                    $max = strlen($chars);
                    $i = 0;
                    while ($i < 12) { 
                        $char = substr($chars, mt_rand(0, $max-1), 1);
                        if (!strstr($logsalt, $char)) { 
                            $logsalt .= $char;
                            $i++;
                        }
                    }
                    OW::getDbo()->query("INSERT INTO `" . OW_DB_PREFIX . "twofactauth_logsalt` (userId, salt) VALUES (".OW::getUser()->getId().", '".$logsalt."')");
                }else{
                    $logsalt = $response['salt'];
                }
                if(isset($data['save'])) setcookie('twofactauth_savelog_'.OW::getUser()->getId(), md5(OW::getUser()->getId().OW_PASSWORD_SALT.$logsalt), strtotime('+1 year'), '/');
				OW::getApplication()->redirect("");
			} else {
				OW::getFeedback()->warning(OW::getLanguage()->text('twofactauth', 'login_fail'));
			}
		}
        
        $this->assign('url_help', OW::getRouter()->urlForRoute('twofactauth.help'));
        $this->assign('url_nocode', OW::getRouter()->urlForRoute('twofactauth.nocode'));
	}

    public function nocode()
    {
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();

		$this->setPageTitle(OW::getLanguage()->text('twofactauth', 'pages_nocode')); 
        $this->setPageHeading(OW::getLanguage()->text('twofactauth', 'pages_nocode')); 

        $form = new Form('twofactauth');
        $fieldEmail = new TextField('email');
        $fieldEmail->setRequired();
        $fieldEmail->addAttribute('placeholder', 'Email');
        $valEmail = new EmailValidator();
        $valEmail->setErrorMessage(OW::getLanguage()->text('twofactauth', 'error_email'));
        $fieldEmail->addValidator($valEmail);
        $form->addElement($fieldEmail);
        $fieldSubmit = new Submit('send');
        $form->addElement($fieldSubmit);

        $this->addForm($form);
        
        OW::getDocument()->getMasterPage()->setTemplate(OW::getThemeManager()->getMasterPageTemplate('mobile_blank'));

        if(OW::getRequest()->isPost() && $form->isValid($_POST))
        {
            $data = $form->getValues();
            $res = OW::getDbo()->queryForRow("SELECT email FROM `".OW_DB_PREFIX."base_user` WHERE id = ".OW::getUser()->getId());

            if($data['email'] == $res['email'])
            {
                $chars = "ab1cd2ef3gh4ij5kl6mn7op8qr9st0uvAwxByz";
                $token = "";

                for($i=0;$i<12;$i++)
                    $token .= substr($chars, mt_rand(0,37), 1);

                OW::getDbo()->query("INSERT INTO `" . OW_DB_PREFIX . "twofactauth_otc` (userId, token, expire) VALUES (".OW::getUser()->getId().", '".$token."', ".strtotime("+30 minutes").")");
                
                $mail = OW::getMailer()->createMail();
                $mail->addRecipientEmail($res['email']);
                $mail->setReplyTo(OW::getConfig()->getValue('base', 'site_email'));
                $mail->setSender(OW::getConfig()->getValue('base', 'site_email'), OW::getConfig()->getValue('base', 'site_name'));
                $mail->setSubject("Authenticator - ".OW::getLanguage()->text('twofactauth', 'nocode_otc'));
                $mail->setHtmlContent("<h1>".OW::getConfig()->getValue('base', 'site_name')."</h1>".OW::getLanguage()->text('twofactauth', 'nocode_email_html')."<br><br><a href='".OW::getRouter()->urlForRoute('twofactauth.token', array('token' => $token))."'>".OW::getLanguage()->text('twofactauth', 'nocode_email_click')."</a>");
                $mail->setTextContent(OW::getConfig()->getValue('base', 'site_name')."\r\n\r\n".str_replace("<br>", "\r\n", OW::getLanguage()->text('twofactauth', 'nocode_email_html'))."\r\n\r\nn".OW::getRouter()->urlForRoute('twofactauth.token', array('token' => $token)));
                OW::getMailer()->send($mail);
            }

            OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'nocode_info'));
        }
    }
    
    public function token($param)
    {
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();

        if(count(OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_otc` WHERE token = '".$param['token']."' AND expire > ".time()."  AND userId = ".OW::getUser()->getId())) > 0)
        {
            OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'login_success'));
		    OW::getSession()->set('twofactauth.logged', true);
            OW::getDbo()->query("DELETE FROM `" . OW_DB_PREFIX . "twofactauth_otc` WHERE userId = ".OW::getUser()->getId());
            $this->redirect("");
        }
        else
        {
        OW::getFeedback()->error(OW::getLanguage()->text('twofactauth', 'error_expired'));
            $this->redirect("");
        }
    }
}