<?php

OW::getRouter()->addRoute(new OW_Route('twofactauth.verify', 'login/verify', "TWOFACTAUTH_MCTRL_Login", 'verify')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.verify.o', 'login/verify/:return', "TWOFACTAUTH_MCTRL_Login", 'verify')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.nocode', 'login/no-code', "TWOFACTAUTH_MCTRL_Login", 'nocode')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.help', 'login/help', "TWOFACTAUTH_CTRL_Login", 'help')); 

OW::getRouter()->addRoute(new OW_Route('twofactauth.token', 'login/token/:token', "TWOFACTAUTH_MCTRL_Login", 'token')); 


function before_doc_render( OW_Event $event )
{
	$url = OW::getRouter()->getUri();

	if(OW::getUser()->getId() == 0) return;
	if(OW::getSession()->get('twofactauth.logged') == true) return;
    if($url == "sign-out") return;
    if(substr($url,0,strlen('login/')) == 'login/' && $url != "login/setup") return;
    
	if(OW::getDbo()->query("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth` WHERE userId = '".OW::getUser()->getId()."'") == 0) return;

    if(isset($_COOKIE['twofactauth_savelog_'.OW::getUser()->getId()])) {
        $response = OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_logsalt` WHERE userId = ".OW::getUser()->getId());
        if(isset($response['salt'])) {
            $logsalt = $response['salt'];
            if($_COOKIE['twofactauth_savelog_'.OW::getUser()->getId()] == md5(OW::getUser()->getId().OW_PASSWORD_SALT.$logsalt)) {
                OW::getSession()->set('twofactauth.logged', true);
                return;
            }
        }
    }
    
    OW::getApplication()->redirect("login/verify");
}
OW::getEventManager()->bind('core.before_document_render', 'before_doc_render');


function user_logout( OW_Event $event )
{
	OW::getSession()->delete('twofactauth.logged');
}
OW::getEventManager()->bind('base.user_logout', 'user_logout');