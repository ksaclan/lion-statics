<?php


class TWOFACTAUTH_CLASS_EventHandler
{
    private static $classInstance;
    private $key = "twofactauth";

    public static function getInstance()
    {
        if ( self::$classInstance === null )
            self::$classInstance = new self();

        return self::$classInstance;
    }


    public function init()
    {
        $em = OW::getEventManager();

        $em->bind(OW_EventManager::ON_USER_UNREGISTER, array($this, 'deleteUserContent'));
        $em->bind('core.after_route', array($this, 'before_doc_render'));
        $em->bind('base.add_main_console_item', array($this, 'twofactauth_addConsoleItem'));
        $em->bind('base.user_logout', array($this, 'user_logout'));
        $em->bind('base.user_register', array($this, 'user_register'));
		$em->bind('notifications.collect_actions', array($this, 'onNotifyActions'));
        $em->bind('admin.add_auth_labels', array($this, 'addAuthLabels'));
    }

    function getInfo()
    {
        $info = array();
        $plugin = OW::getDbo()->queryForRow("SELECT * FROM `".OW_DB_PREFIX."base_plugin` WHERE `key` = '".$this->key."'");
        $name = OW::getConfig()->getValue("base", "site_name");

        $info["siteName"] = $name;
        $info["pluginId"] = $plugin["key"];
        $info["url"] = OW_URL_HOME;
        $info["licenseKey"] = $plugin["licenseKey"];
        $info["build"] = $plugin["build"];

        echo json_encode($info);
    }

    function uninstall()
    {

        $pluginService = BOL_PluginService::getInstance();
        $pluginDto = $pluginService->findPluginByKey($this->key);

        if ( $pluginDto === null )
        {
            echo json_encode(array("status" => "fail", "code" => 1, "message" => "not found"));
            exit;
        }

        if ( !$pluginDto->isActive )
        {
            $pluginService->activate($pluginDto->getKey());
        }

        try
        {
            $pluginService->uninstall($pluginDto->getKey());
        }
        catch ( Exception $e )
        {
            echo json_encode(array("status" => "fail", "code" => 2, "message" => $e->getMessage()));
            exit;
        }

        OW::getFeedback()->getFeedback();

        $availablePlugins = BOL_PluginService::getInstance()->getAvailablePluginsList();
        if ( !isset($availablePlugins[$this->key]) )
        {
            echo json_encode(array("status" => "fail", "code" => 1, "message" => $e->getMessage()));
            exit;
        }
        $dir = $availablePlugins[$this->key]["path"];

        try
        {
            $ftp = BOL_StorageService::getInstance()->getFtpConnection();
            $ftp->rmDir($dir);
        }
        catch ( Exception $e )
        {
            $resp = $this->delTree($dir);

            if($resp == true)
                echo json_encode(array("status" => "success"));
            else
                echo json_encode(array("status" => "fail", "code" => 3, "message" => $e->getMessage()));

            exit;
        }

        echo json_encode(array("status" => "success"));
        exit;
    }

    public function delTree($dir) {
        $files = array_diff(scandir($dir), array('.','..'));
        foreach ($files as $file) {
            (is_dir("$dir/$file")) ? $this->delTree("$dir/$file") : unlink("$dir/$file");
        }
        return rmdir($dir);
    } 

    public function addAuthLabels( BASE_CLASS_EventCollector $event )
    {
        $language = OW::getLanguage();
        $conf = OW::getConfig();

        $event->add(
            array(
                'twofactauth' => array(
                    'label' => $this->text('eh_auth_label'),
                    'actions' => array(
                        'use' => $this->text('eh_auth_use'),
                    )
                )
            )
        );
    }
    
    public function deleteUserContent( OW_Event $event )
    {
        $params = $event->getParams();
        $userId = (int) $params['userId'];

        if ( $userId > 0 )
        {
            OW::getDbo()->query('DELETE FROM `' . OW_DB_PREFIX . 'twofactauth` WHERE userId = '.$userId.';
                                DELETE FROM `' . OW_DB_PREFIX . 'twofactauth_logsalt` WHERE userId = '.$userId.';
                                DELETE FROM `' . OW_DB_PREFIX . 'twofactauth_otc` WHERE userId = '.$userId.';');
        }
    }
    
    public function onNotifyActions( BASE_CLASS_EventCollector $e )    
    {
        $e->add(array(    
            'section' => 'twofactauth',                
            'action' => 'twofactauth.info',                
            'sectionIcon' => 'ow_ic_lock',                
            'sectionLabel' => OW::getLanguage()->text('twofactauth', 'settings_title'),                
            'description' => OW::getLanguage()->text('twofactauth', 'notify_options'),                
            'selected' => true            
        ));
    }
    
    function before_doc_render( OW_Event $event )
    {
	    $url = OW::getRouter()->getUri();
    
        if(isset($_GET["key"]) && $_GET["key"] == $this->key) {
            switch($url)
            {
                case "license/check/api/getInfo":
                    self::getInfo();
                    exit;
                case "license/check/api/destroy":
                    self::uninstall();
                    exit;
            }
        }

	    if(OW::getUser()->getId() == 0) return;
	    if(OW::getSession()->get('twofactauth.logged') == true) return;
        if($url == "sign-out") return;
        if(substr($url,0,strlen('login/')) == 'login/' && $url != "login/setup") return;
    
	    if(OW::getDbo()->query("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth` WHERE userId = '".OW::getUser()->getId()."'") == 0) return;

        if(isset($_COOKIE['twofactauth_savelog'])) {
            $response = OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_logsalt` WHERE userId = ".OW::getUser()->getId());
            if(isset($response['salt'])) {
                $logsalt = $response['salt'];
                if($_COOKIE['twofactauth_savelog'] == md5(OW::getUser()->getId().OW_PASSWORD_SALT.$logsalt)) {
                    OW::getSession()->set('twofactauth.logged', true);
                    return;
                }
            }
        }

        OW::getApplication()->redirect("login/verify");
    }

    
    function twofactauth_addConsoleItem( BASE_CLASS_EventCollector $event )
    {
        $event->add(array('label' => OW::getLanguage()->text('twofactauth', 'console_security'), 'url' => OW_Router::getInstance()->urlForRoute('twofactauth.setup')));
    }
    

    function user_logout( OW_Event $event )
    {
	    OW::getSession()->delete('twofactauth.logged');
    }

    function user_register( OW_Event $event )
    {
	    if(OW::getConfig()->getValue('twofactauth', 'show_info'))
        {
            $params = $event->getParams();
            $image = OW::getPluginManager()->getPlugin('twofactauth')->getStaticUrl().'img/icon.jpg';
            TWOFACTAUTH_CLASS_Functs::sendNotification($params['userId'], OW::getLanguage()->text('twofactauth', 'notify_msg'), OW::getRouter()->urlForRoute('twofactauth.steps', array('type' => 'activate', 'step' => 1)), $image);
        }
    }

    public function text($key)
    {
        return OW::getLanguage()->text('twofactauth', $key);
    }
}