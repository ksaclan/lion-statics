<?php

class TWOFACTAUTH_CLASS_Functs
{
    /*
    * $uid - Die UserId des Empfängers
    * $message - Die zu überbringende Nachricht
    */
    public static function sendNotification($uid, $message, $url, $image = null){
        $plugin = array( 			'pluginKey' => 'twofactauth',			'entityType' => 'twofactauth-example',			'entityId' => $uid,			'action' => 'twofactauth.info',			'userId' => $uid,			'time' => time()		);				$params = array(			'avatar' => array("src" => $image),			'string' => $message,			'content' => $message,			'url' => $url,		);				$event = new OW_Event('notifications.add', $plugin, $params);		OW::getEventManager()->trigger($event);
    }
}