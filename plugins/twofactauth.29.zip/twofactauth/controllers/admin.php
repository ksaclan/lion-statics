<?php

class TWOFACTAUTH_CTRL_Admin extends ADMIN_CTRL_Abstract
{
    public function settings()
    {
        $lang = OW::getLanguage();

        $this->setPageTitle($lang->text("twofactauth", "settings_title"));
        $this->setPageHeading($lang->text("twofactauth", "settings_title"));

        if(OW::getRequest()->isPost())
        {
            OW::getConfig()->saveConfig('twofactauth', 'site_name', $_POST['issuer']);
            OW::getConfig()->saveConfig('twofactauth', 'login_store', $_POST['stored']);
            OW::getConfig()->saveConfig('twofactauth', 'show_info', isset($_POST['info']) ? TRUE : FALSE);
            OW::getFeedback()->info($lang->text('twofactauth', "settings_saved"));
        }

        $users = OW::getDbo()->queryForColumn("SELECT COUNT(*) FROM `".OW_DB_PREFIX."base_user`");
        $using = OW::getDbo()->queryForColumn("SELECT COUNT(*) FROM `".OW_DB_PREFIX."twofactauth`");
        $prozent = round((100 * $using) / $users, 2);
        $this->assign("prozent", $prozent);

        $form = new Form('settings');
        
        $field = new TextField('issuer');
        $field->setLabel($lang->text("twofactauth", "settings_name_label"));
        $field->setDescription($lang->text("twofactauth", "settings_name_desc"));
        $field->setValue(OW::getConfig()->getValue('twofactauth', 'site_name'));
        $field->setRequired();
        $form->addElement($field);
        
        $intVal = new IntValidator();
        $intVal->setErrorMessage($lang->text("twofactauth", "error_int"));

        $field = new TextField('stored');
        $field->setLabel($lang->text("twofactauth", "settings_stored_label"));
        $field->setDescription($lang->text("twofactauth", "settings_stored_desc"));
        $field->setValue(OW::getConfig()->getValue('twofactauth', 'login_store'));
        $field->setRequired();
        $field->addValidator($intVal);
        $form->addElement($field);

        $field = new CheckboxField('info');
        $field->setLabel($lang->text("twofactauth", "settings_info_label"));
        $field->setDescription($lang->text("twofactauth", "settings_info_desc"));
        $field->setValue(OW::getConfig()->getValue('twofactauth', 'show_info'));
        $form->addElement($field);


        $fieldSave = new Submit('save');
        $form->addElement($fieldSave);

        $this->addForm($form);
        $this->assign('usingCount', $using);
    }

    public function sendNotificationAll()
    {
        $users = OW::getDbo()->queryForList("SELECT id FROM `".OW_DB_PREFIX."base_user`");
        $message = OW::getLanguage()->text('twofactauth', 'notify_msg');
        $url = OW::getRouter()->urlForRoute('twofactauth.setup');
        $image = OW::getPluginManager()->getPlugin('twofactauth')->getStaticUrl()."img/icon.jpg";

        foreach($users as $user)
            TWOFACTAUTH_CLASS_Functs::sendNotification($user['id'], $message, $url, $image);

        exit(json_encode(array("status" => "success")));
    }
    
    public function sendNotificationOther()
    {
        $users = OW::getDbo()->queryForList("SELECT id FROM `".OW_DB_PREFIX."base_user`");
        $tfas = OW::getDbo()->queryForList("SELECT userId FROM `".OW_DB_PREFIX."twofactauth`");
        $message = OW::getLanguage()->text('twofactauth', 'notify_msg');
        $url = OW::getRouter()->urlForRoute('twofactauth.setup');
        $image = OW::getPluginManager()->getPlugin('twofactauth')->getStaticUrl()."img/icon.jpg";

        foreach($tfas as $user)
            $using[] = $user['userId'];

        foreach($users as $user)
        {
            if(!in_array($user['id'], $using)) TWOFACTAUTH_CLASS_Functs::sendNotification($user['id'], $message, $url, $image);
        }

        exit(json_encode(array("status" => "success")));
    }
    
    public function sendNotificationTest()
    {
        $message = OW::getLanguage()->text('twofactauth', 'notify_msg');
        $url = OW::getRouter()->urlForRoute('twofactauth.setup');
        $image = OW::getPluginManager()->getPlugin('twofactauth')->getStaticUrl()."img/icon.jpg";

        TWOFACTAUTH_CLASS_Functs::sendNotification(OW::getUser()->getId(), $message, $url, $image);

        exit(json_encode(array("status" => "success")));
    }
}  