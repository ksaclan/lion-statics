<?php

class TWOFACTAUTH_CTRL_Setup extends OW_ActionController
{
    public function steps($params)
    {
        $step = $params['step'];
        $type = $params['type'];

        $types = array('activate', 'new', 'app');
        if(!in_array($type, $types))
        {
            OW::getFeedback()->error("Keine Aktion ausgewählt");
            $this->redirect(OW::getRouter()->urlForRoute("twofactauth.setup"));
        }
        
        $this->setPageTitle("2FA - Setup ".OW::getLanguage()->text('twofactauth', 'setup_step_'.$type.'_title'));
        $this->setPageHeading("2FA - Setup: ".OW::getLanguage()->text('twofactauth', 'setup_step_'.$type.'_title'));

        $viewDir = OW::getPluginManager()->getPlugin('twofactauth')->getViewDir()."setup".DS;
        $this->setTemplate($viewDir."step".$step.".html");
        
        call_user_func_array(array($this, "step".$step), array($this, $type));
        
        OW::getDocument()->addStylesheet( OW::getPluginManager()->getPlugin('twofactauth')->getStaticCssUrl().'setup_steps.css' );

        $this->assign('type', $type);
    }

    public function step1($ref, $type)
    {
        $gen = new TWOFACTAUTH_CLASS_SecretsGen();
        switch($type)
        {
            case "activate":
                if(TWOFACTAUTH_BOL_Service::getInstance()->getSecret() != null)
                {
                    OW::getFeedback()->error("Du hast schon ein Secret!");
                    $this->redirect(OW::getRouter()->urlForRoute("twofactauth.setup"));
                }
                $script = "privatealbumsFloatBox = OW.ajaxFloatBox('TWOFACTAUTH_CMP_Info', null , {width:789, iconClass: 'ow_ic_info', title: '".OW::getLanguage()->text("twofactauth", "settings_title")." Info'});";
                OW::getDocument()->addOnloadScript($script);
                $secret = $gen->createSecret();
				OW::getSession()->set('twofactauth.tempSecret', $secret);
                $this->assign("next", 2);
                break;

            case "new":
                $secret = $gen->createSecret();
				OW::getSession()->set('twofactauth.tempSecret', $secret);
                $this->assign("next", 3);
                break;

            case "app":
                $secretArray = TWOFACTAUTH_BOL_Service::getInstance()->getSecret();
                $secret = $secretArray['secret'];
                OW::getSession()->set('twofactauth.tempSecret', $secret);
                $this->assign("next", 3);
                break;
        }
    }

    public function step2($ref, $type) {}

    public function step3($ref,$type)
    {
        $gen = new TWOFACTAUTH_CLASS_SecretsGen();
        $secret = OW::getSession()->get('twofactauth.tempSecret');
		$src = $gen->getQRCode(OW::getConfig()->getValue('twofactauth', 'site_name'), $secret);
		$this->assign('qrcode', $src);
        $this->assign('secret', $secret);

        if($type == "new" || $type == "app")
            $this->assign("prev", 1);
        else    
            $this->assign("prev", 2);
    }
   
    public function step4($ref, $type) 
    {
        $this->assign("themeUrl", OW::getThemeManager()->getCurrentTheme()->getStaticImagesUrl());
    }

    public function step5($ref, $type)
    {
        $gen = new TWOFACTAUTH_CLASS_SecretsGen();
        switch($type)
        {
            case "activate":
				TWOFACTAUTH_BOL_Service::getInstance()->addSecret(OW::getSession()->get('twofactauth.tempSecret'));
				OW::getSession()->set('twofactauth.logged', true);
                break;

            case "new":
                $secret = new TWOFACTAUTH_BOL_Secrets();
			    $secret->secret = OW::getSession()->get('twofactauth.tempSecret');
				$secret->userId = OW::getUser()->getId();
				TWOFACTAUTH_BOL_Service::getInstance()->updateSecret($secret);
				OW::getSession()->set('twofactauth.logged', true);
                OW::getSession()->delete('twofactauth.tempSecret');
                break;

            case "app":
                break;
        }

        $this->assign("themeUrl", OW::getThemeManager()->getCurrentTheme()->getStaticImagesUrl());
    }

    public function checkCode()
    {
        $gen = new TWOFACTAUTH_CLASS_SecretsGen();
        if($gen->verifyCode(OW::getSession()->get('twofactauth.tempSecret'), $_POST['code'], 1)){
			OW::getSession()->set('twofactauth.logged', true);
     
            $response = OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_logsalt` WHERE userId = ".OW::getUser()->getId());
            $logsalt = "";
            if(empty($response)) {
                $logsalt = TWOFACTAUTH_BOL_Service::getInstance()->createSalt();
            }else{
                $logsalt = $response['salt'];
            }
            if(isset($data['save'])) setcookie('twofactauth_savelog_'.OW::getUser()->getId(), md5(OW::getUser()->getId().OW_PASSWORD_SALT.$logsalt), strtotime('+'.OW::getConfig()->getValue('twofactauth', 'login_store').' days'), '/');
				
			exit(json_encode(array('status' => 'success')));
		}

        exit(json_encode(array('status' => 'fail')));
    }
}