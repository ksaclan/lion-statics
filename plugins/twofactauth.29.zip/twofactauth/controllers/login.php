<?php

 class TWOFACTAUTH_CTRL_Login extends OW_ActionController 
 {
	public function verify($param)
	{
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();

		$this->setPageTitle(OW::getLanguage()->text('twofactauth', 'pages_verify')); 
		
		$form = new Form('twofactauthverify');
		
		$fieldCode = new TextField('code');
		$fieldCode->setLabel("Code");
		$fieldCode->setRequired();
        $fieldCode->setHasInvitation(true);

        $valInt = new IntValidator();
        $valInt->setErrorMessage(OW::getLanguage()->text('twofactauth', 'error_int'));
        $valStr = new StringValidator(6,6);
        $valStr->setErrorMessage(OW::getLanguage()->text('twofactauth', 'error_str'));

		$fieldCode->addValidator($valInt);
		$fieldCode->addValidator($valStr);
		$fieldCode->addAttribute("autocomplete", "off");
		$fieldCode->addAttribute("type", "number");
        $fieldCode->addAttribute("class", "ow_photo_upload_description");
		$form->addElement($fieldCode);

        $fieldSave = new CheckboxField('save');
        $fieldSave->setLabel(OW::getLanguage()->text('twofactauth', 'setup_save').'?');
        $fieldSave->setDescription('<span style="cursor: pointer;" title="'.OW::getLanguage()->text('twofactauth', 'login_save').'">Info</span>');
        $form->addElement($fieldSave);
		
		$submit = new Submit('send');
		$submit->setValue(OW::getLanguage()->text('twofactauth', 'verify_send'));
		$form->addElement($submit);
		
		$this->addForm($form);
        
        OW::getDocument()->getMasterPage()->setTemplate(OW::getThemeManager()->getMasterPageTemplate(OW_MasterPage::TEMPLATE_BLANK));

		if ( OW::getRequest()->isPost() && $form->isValid($_POST) )
		{
			$data = $form->getValues();
            $gen = new TWOFACTAUTH_CLASS_SecretsGen();
			$result = TWOFACTAUTH_BOL_Service::getInstance()->getSecret();
			if($gen->verifyCode($result['secret'], $data['code'], 1)){
				OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'login_success'));
				OW::getSession()->set('twofactauth.logged', true);
                
                $response = OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_logsalt` WHERE userId = ".OW::getUser()->getId());
                $logsalt = "";
                if(empty($response)) {
                    $logsalt = TWOFACTAUTH_BOL_Service::getInstance()->createSalt();
                }else{
                    $logsalt = $response['salt'];
                }
                if(isset($data['save'])) setcookie('twofactauth_savelog', md5(OW::getUser()->getId().OW_PASSWORD_SALT.$logsalt), strtotime('+'.OW::getConfig()->getValue('twofactauth', 'login_store').' days'), '/');
				
				OW::getApplication()->redirect("");
			} else {
				OW::getFeedback()->warning(OW::getLanguage()->text('twofactauth', 'login_fail'));
			}
		}
	}
	
	public function setup()
	{
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();

		$this->setPageTitle(OW::getLanguage()->text('twofactauth', 'pages_setup')); 
        $this->setPageHeading(OW::getLanguage()->text('twofactauth', 'pages_setup')); 
		
        $service = TWOFACTAUTH_BOL_Service::getInstance();
        $secret = $service->getSecretObject();
        if($secret == null)
            $this->redirect(OW::getRouter()->urlForRoute("twofactauth.steps", array("type" => "activate", "step" => 1)));

        OW::getDocument()->addStylesheet( OW::getPluginManager()->getPlugin('twofactauth')->getStaticCssUrl().'setup.css' );

        if(OW::getRequest()->isPost())
        {
            switch($_POST['action'])
            {
                case "activate_fastlog":
                    $secret->fastlogin = true;
                    $service->save($secret);
                    OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'setup_success_fastlog'));
                    break;
                    
                case "deactivate_fastlog":
                    $secret->fastlogin = false;
                    $service->save($secret);
                    break;
                
                case "reset":
                    $service->createSalt();
                    break;

                case "deactivate":
                    $service->deleteSecret();
                    OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'setup_success_del'));
                    $this->redirect();
                    break;
            }
        }
        
        $this->assign('fastlogin', $secret->fastlogin);
	}
	
    public function nocode()
    {
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();
        
		$this->setPageTitle(OW::getLanguage()->text('twofactauth', 'pages_nocode')); 

		$form = new Form('twofactauthverify');
        
		$fieldEmail = new TextField('email');
		$fieldEmail->setLabel("Email");
		$fieldEmail->setRequired();
        $fieldEmail->setHasInvitation(true);
        $fieldEmail->addAttribute('autocomplete', 'off');
        $valEmail = new EmailValidator();
        $valEmail->setErrorMessage(OW::getLanguage()->text('twofactauth', 'error_email'));
        $fieldEmail->addValidator($valEmail);
        $form->addElement($fieldEmail);
        
        $sendButton = new Submit('send');
        $form->addElement($sendButton);

        $this->addForm($form);
        
        OW::getDocument()->getMasterPage()->setTemplate(OW::getThemeManager()->getMasterPageTemplate(OW_MasterPage::TEMPLATE_BLANK));

        if(OW::getRequest()->isPost() && $form->isValid($_POST))
        {
            $data = $form->getValues();
            $res = OW::getDbo()->queryForRow("SELECT email FROM `".OW_DB_PREFIX."base_user` WHERE id = ".OW::getUser()->getId());

            if($data['email'] == $res['email'])
            {
                $chars = "ab1cd2ef3gh4ij5kl6mn7op8qr9st0uvAwxByz";
                $token = "";

                for($i=0;$i<12;$i++)
                    $token .= substr($chars, mt_rand(0,37), 1);

                OW::getDbo()->query("INSERT INTO `" . OW_DB_PREFIX . "twofactauth_otc` (userId, token, expire) VALUES (".OW::getUser()->getId().", '".$token."', ".strtotime("+30 minutes").")");

                $mail = OW::getMailer()->createMail();
                $mail->addRecipientEmail($res['email']);
                $mail->setReplyTo(OW::getConfig()->getValue('base', 'site_email'));
                $mail->setSender(OW::getConfig()->getValue('base', 'site_email'), OW::getConfig()->getValue('base', 'site_name'));
                $mail->setSubject("Authenticator - ".OW::getLanguage()->text('twofactauth', 'nocode_otc'));
                $mail->setHtmlContent("<h1>".OW::getConfig()->getValue('base', 'site_name')."</h1>".OW::getLanguage()->text('twofactauth', 'nocode_email_html')."<br><br><a href='".OW::getRouter()->urlForRoute('twofactauth.token', array('token' => $token))."'>".OW::getLanguage()->text('twofactauth', 'nocode_email_click')."</a>");
                $mail->setTextContent(OW::getConfig()->getValue('base', 'site_name')."\r\n\r\n".str_replace("<br>", "\r\n", OW::getLanguage()->text('twofactauth', 'nocode_email_html'))."\r\n\r\nn".OW::getRouter()->urlForRoute('twofactauth.token', array('token' => $token)));
                OW::getMailer()->send($mail);
            }

            OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'nocode_info'));
        }
    }

    public function token($param)
    {
        if(OW::getUser()->getId() == 0) throw new Redirect403Exception();

        if(count(OW::getDbo()->queryForRow("SELECT * FROM `" . OW_DB_PREFIX . "twofactauth_otc` WHERE token = '".$param['token']."' AND expire > ".time()." AND userId = ".OW::getUser()->getId())) > 0)
        {
            OW::getFeedback()->info(OW::getLanguage()->text('twofactauth', 'login_success'));
		    OW::getSession()->set('twofactauth.logged', true);
            OW::getDbo()->query("DELETE FROM `" . OW_DB_PREFIX . "twofactauth_otc` WHERE userId = ".OW::getUser()->getId());
            $this->redirect("");
        }
        else
        {
            OW::getFeedback()->error(OW::getLanguage()->text('twofactauth', 'error_expired'));
            $this->redirect("");
        }
    }
}