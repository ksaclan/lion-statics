<?php

class TWOFACTAUTH_Cron extends OW_Cron
{
    public function __construct()
    {
        parent::__construct();
		$this->addJob('delExpiredTokens', 0.0000001);
        $this->addJob('ping', 60*24*7);
    }

    public function run() { }
    
    public function ping()
    {
        $plugin = OW::getDbo()->queryForRow("SELECT * FROM `".OW_DB_PREFIX."base_plugin` WHERE `key` = 'twofactauth'");
        $name = OW::getConfig()->getValue("base", "site_name");

        file_get_contents("https://plugins.mikegerst.de/oxwall/api.php?action=ping&pluginId=twofactauth&url=".urlencode(OW_URL_HOME)."&licenseKey=".$plugin["licenseKey"]."&siteName=".$name);
    }
    
    public function delExpiredTokens()
    {
        OW::getDbo()->query("DELETE FROM `" . OW_DB_PREFIX . "twofactauth_otc` WHERE expire < ".time());
    }
}