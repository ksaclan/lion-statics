<?php
 class TWOFACTAUTH_BOL_Service
{
    private static $classInstance;
 
    public static function getInstance()
    {
        if ( self::$classInstance === null )
        {
            self::$classInstance = new self();
        }
 
        return self::$classInstance;
    }
 
    public $dao;
 
    private function __construct()
    {
		$this->dao = TWOFACTAUTH_BOL_SecretsDao::getInstance();
    }
	
	public function createSalt()
	{
		$logsalt = "";
        $chars = "012346789ABCDEFGHIJKLMNOPQRSTUVWXYZ#!$&%";
        $max = strlen($chars);
        $i = 0;
        while ($i < 12) { 
            $char = substr($chars, mt_rand(0, $max-1), 1);
            if (!strstr($logsalt, $char)) { 
                $logsalt .= $char;
                $i++;
            }
        }
		
		$query = "DELETE FROM `" . OW_DB_PREFIX . "twofactauth_logsalt` WHERE userId = ".OW::getUser()->getId().";
                  INSERT INTO `" . OW_DB_PREFIX . "twofactauth_logsalt` (userId, salt) VALUES (".OW::getUser()->getId().", '".$logsalt."')";
		OW::getDbo()->query($query);
		
		return $logsalt;
	}
 
    public function addSecret($secret)
    {
        $sec = new TWOFACTAUTH_BOL_Secrets();
        $sec->secret = $secret;
		$sec->userId = OW::getUser()->getId();
        TWOFACTAUTH_BOL_SecretsDao::getInstance()->save($sec);
    }
	
	public function updateSecret(TWOFACTAUTH_BOL_Secrets $sec)
	{
		$sql="UPDATE `" . OW_DB_PREFIX . "twofactauth`
			SET secret = '".$sec->secret."'
			WHERE userId = ".$sec->userId;
		return OW::getDbo()->query( $sql );
	}
 
    public function deleteSecret( $id = 0)
    {
        if($id == 0)
        {
            $secret = $this->getSecret();
            if($secret == null) return;
            $id = $secret['id'];
        }

        if ( $id > 0 ) TWOFACTAUTH_BOL_SecretsDao::getInstance()->deleteById($id);
    }
 
    public function getSecret()
    {
		return $this->getSecretByUserId(OW::getUser()->getId());
    }
 
    public function getSecretObject()
    {
		$sql = 'SELECT * FROM `' . OW_DB_PREFIX . 'twofactauth` WHERE userId = '.OW::getUser()->getId();
        return OW::getDbo()->queryForObject($sql, "TWOFACTAUTH_BOL_Secrets");
    }
 
    public function getSecretByUserId($id)
    {
        $sql = 'SELECT * FROM `' . OW_DB_PREFIX . 'twofactauth` WHERE userId = '.$id;
		return OW::getDbo()->queryForRow( $sql );
    }
 
    public function getSecretList()
    {
        return $this->dao->findAll();
    }
    
    public function save($secret)
    {
        $this->dao->save($secret);
    }
}