<?php
 class TWOFACTAUTH_BOL_Secrets extends OW_Entity
 {
    public $secret;
	public $userId;
	public $fastlogin = false;
 }