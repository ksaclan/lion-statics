<?php
 class TWOFACTAUTH_BOL_SecretsDao extends OW_BaseDao
 {
 
    protected function __construct()
    {
        parent::__construct();
    }
    private static $classInstance;
 
    public static function getInstance()
    {
        if ( self::$classInstance === null )
        {
            self::$classInstance = new self();
        }
 
        return self::$classInstance;
    }
 
    public function getDtoClassName()
    {
        return 'TWOFACTAUTH_BOL_Secrets';
    }
 
    /**
     * @see OW_BaseDao::getTableName()
     *
     */
    public function getTableName()
    {
        return OW_DB_PREFIX . 'twofactauth';
    }
}