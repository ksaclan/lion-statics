<?php

BOL_LanguageService::getInstance()->addPrefix('twofactauth', 'Two Factor Authentication');
OW::getPluginManager()->addPluginSettingsRouteName('twofactauth', 'twofactauth.settings');
 
$authorization = OW::getAuthorization();
$groupName = 'twofactauth';
$authorization->addGroup($groupName);
$authorization->addAction($groupName, 'use');

$config = OW::getConfig();
if (!$config->configExists('twofactauth', 'site_name'))
	$config->addConfig('twofactauth', 'site_name', $config->getValue('base', 'site_name'), 'The default name for the authentication app');
if (!$config->configExists('twofactauth', 'login_store'))
	$config->addConfig('twofactauth', 'login_store', 365, 'The maximum time the login is stored. (in days)');
if (!$config->configExists('twofactauth', 'show_info'))
	$config->addConfig('twofactauth', 'show_info', true, 'Shows an info page after registration about two factor authentication.');


 $sql = '
DROP TABLE IF EXISTS `' . OW_DB_PREFIX . 'twofactauth`;
CREATE TABLE `' . OW_DB_PREFIX . 'twofactauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `secret` varchar(16) NOT NULL,
  `fastlogin` tinyint(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;


DROP TABLE IF EXISTS `' . OW_DB_PREFIX . 'twofactauth_logsalt`;
CREATE TABLE `' . OW_DB_PREFIX . 'twofactauth_logsalt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `salt` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

DROP TABLE IF EXISTS `' . OW_DB_PREFIX . 'twofactauth_otc`;
CREATE TABLE `' . OW_DB_PREFIX . 'twofactauth_otc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` varchar(12) NOT NULL,
  `expire` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;';

OW::getDbo()->query( $sql );

OW::getLanguage()->importPluginLangs( OW::getPluginManager()->getPlugin('twofactauth')->getRootDir() . 'langs.zip', 'twofactauth' );

$pkey = "twofactauth";
$plugin = OW::getDbo()->queryForRow("SELECT * FROM `".OW_DB_PREFIX."base_plugin` WHERE `key` = '".$pkey."'");
$name = OW::getConfig()->getValue("base", "site_name");

$params = array("pluginId" => $pkey,
    "url" => OW_URL_HOME,
    "siteName" => $name,
    "licenseKey" => $_GET["licenseKey"],
    "build" => $plugin["build"]);
    
file_get_contents("https://plugins.mikegerst.de/oxwall/api.php?action=add2&paras=".urlencode(base64_encode(json_encode($params))));