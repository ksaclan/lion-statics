<?php

$pkey = "twofactauth";
$plugin = OW::getDbo()->queryForRow("SELECT * FROM `".OW_DB_PREFIX."base_plugin` WHERE `key` = '".$pkey."'");
$name = OW::getConfig()->getValue("base", "site_name");

$params = array("pluginId" => $pkey,
    "url" => OW_URL_HOME,
    "siteName" => $name,
    "licenseKey", $plugin["licenseKey"],
    "build" => 28);
    
file_get_contents("https://plugins.mikegerst.de/oxwall/api.php?action=add2&paras=".urlencode(base64_encode(json_encode($params))));