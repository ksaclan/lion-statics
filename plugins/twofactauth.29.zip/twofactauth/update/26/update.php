<?php 

$plugin = OW::getDbo()->queryForRow("SELECT * FROM `".OW_DB_PREFIX."base_plugin` WHERE `key` = 'twofactauth'");
$name = OW::getConfig()->getValue("base", "site_name");

file_get_contents("https://plugins.mikegerst.de/oxwall/ping.php?action=ping&pluginId=twofactauth&url=".urlencode(OW_URL_HOME)."&licenseKey=".$plugin["licenseKey"]."&siteName=".$name."&build=".$plugin["build"]);