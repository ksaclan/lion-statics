<?php

Updater::getLanguageService()->importPrefixFromZip(dirname(__FILE__) . DS . 'langs.zip', 'twofactauth');

$query = 'CREATE TABLE IF NOT EXISTS `' . OW_DB_PREFIX . 'twofactauth_logsalt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `salt` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;';

Updater::getDbo()->query($query);