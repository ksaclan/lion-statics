<?php 

OW::getLanguage()->importPluginLangs( OW::getPluginManager()->getPlugin('twofactauth')->getRootDir() . 'langs.zip', 'twofactauth' );