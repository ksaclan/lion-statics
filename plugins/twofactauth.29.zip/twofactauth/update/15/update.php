<?php


$config = OW::getConfig();

if (!$config->configExists('twofactauth', 'login_store'))
	$config->addConfig('twofactauth', 'login_store', 365, 'The maximum time the login is stored. (in days)');
    
if (!$config->configExists('twofactauth', 'show_info'))
	$config->addConfig('twofactauth', 'show_info', true, 'Shows an info page after registration about two factor authentication.');


    
Updater::getLanguageService()->importPrefixFromZip(dirname(__FILE__) . DS . 'langs.zip', 'twofactauth');