<?php

$config = OW::getConfig();
if (!$config->configExists('twofactauth', 'site_name')){
	$config->addConfig('twofactauth', 'site_name', $config->getValue('base', 'site_name'), 'The default name for the authentication app');
}