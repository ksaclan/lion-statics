<?php  
try {
	OW::getDbo()->query("ALTER TABLE `".OW_DB_PREFIX."twofactauth` ADD `fastlogin` TINYINT(1) NOT NULL ;");
} catch(Exception $ex) {
	
}