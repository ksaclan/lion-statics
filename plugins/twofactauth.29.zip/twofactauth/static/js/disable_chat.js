$('#dialogsContainer').css('display', 'none');
$('.ow_chat_cont').css('display', 'none');
            
$('.ow_mailbox_items_list').remove();
$('.ow_notification_list').remove();

setTimeout(function() {
    $('#dialogsContainer').remove();  $('.ow_chat_cont').remove();
}, 1000);