<?php

OW::getRouter()->addRoute(new OW_Route('twofactauth.settings', 'admin/plugins/twofactauth/settings', "TWOFACTAUTH_CTRL_Admin", 'settings')); 

OW::getRouter()->addRoute(new OW_Route('twofactauth.steps', 'login/setup/:type/step/:step', "TWOFACTAUTH_CTRL_Setup", 'steps')); 

OW::getRouter()->addRoute(new OW_Route('twofactauth.verify', 'login/verify', "TWOFACTAUTH_CTRL_Login", 'verify')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.verify.o', 'login/verify/:return', "TWOFACTAUTH_CTRL_Login", 'verify')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.setup', 'login/setup', "TWOFACTAUTH_CTRL_Login", 'setup'));
OW::getRouter()->addRoute(new OW_Route('twofactauth.nocode', 'login/no-code', "TWOFACTAUTH_CTRL_Login", 'nocode'));
OW::getRouter()->addRoute(new OW_Route('twofactauth.token', 'login/token/:token', "TWOFACTAUTH_CTRL_Login", 'token')); 

OW::getRouter()->addRoute(new OW_Route('twofactauth.ajax.sendnotify.all', 'twofactauth/admin/sendNotification/all', "TWOFACTAUTH_CTRL_Admin", 'sendNotificationAll')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.ajax.sendnotify.other', 'twofactauth/admin/sendNotification/other', "TWOFACTAUTH_CTRL_Admin", 'sendNotificationOther')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.ajax.sendnotify.test', 'twofactauth/admin/sendNotification/test', "TWOFACTAUTH_CTRL_Admin", 'sendNotificationTest')); 
OW::getRouter()->addRoute(new OW_Route('twofactauth.ajax.checkcode', 'twofactauth/setup/checkCode', "TWOFACTAUTH_CTRL_Setup", 'checkCode')); 

if(isset($_GET['loadlang']) && $_GET['loadlang'] == "tfa") 
    OW::getLanguage()->importPluginLangs( OW::getPluginManager()->getPlugin('twofactauth')->getRootDir() . 'langs.zip', 'twofactauth' );

TWOFACTAUTH_CLASS_EventHandler::getInstance()->init();

$path = OW::getPluginManager()->getPlugin('twofactauth')->getClassesDir()."standard_auth.php";
OW::getAutoloader()->addClass("BASE_CLASS_StandardAuth", $path);