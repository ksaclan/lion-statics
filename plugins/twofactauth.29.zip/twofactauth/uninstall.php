<?php

$sql = 'DROP TABLE IF EXISTS `' . OW_DB_PREFIX . 'twofactauth`;
DROP TABLE IF EXISTS `' . OW_DB_PREFIX . 'twofactauth_logsalt`;
DROP TABLE IF EXISTS `' . OW_DB_PREFIX . 'twofactauth_otc`;';
OW::getDbo()->query( $sql );

$params = array("pluginId" => "twofactauth", "url" => OW_URL_HOME);
echo file_get_contents("https://plugins.mikegerst.de/oxwall/api.php?action=delete&paras=".urlencode(base64_encode(json_encode($params))));