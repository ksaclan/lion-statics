<?php
    
class TWOFACTAUTH_CMP_Info extends OW_Component
{
	public function __construct()
	{

	}
}