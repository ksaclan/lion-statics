var OW_ReCaptcha = function( $params )
{
    var self = this;

    //this.errors = [];
    this.captchaId = $params.captchaId;
    this.responderUrl = $params.responderUrl;
    this.userIp = $params.userIp;
    this.captcha = $( '#' + this.captchaId );
    this.form = $( this.captcha.parents('form').get(0) );
    this.theme = $params.theme
    this.language = $params.language
    this.widget = null;
    this.error = '';

    this.init = function()
    {
        var $theme = "red";
        var $lang = "en";

        if ( self.theme )
        {
            $theme = self.theme;
        }

        if ( self.language )
        {
            $lang = self.language;
        }

        window.onReacptchaLoadCallback = function() {
           self.widget = grecaptcha.render(self.captchaId, {
             'sitekey' : $params.publickey,
             'theme' : self.theme,
             'type' : 'image',
             'lang': self.language
           });
         };
         
//        Recaptcha.create($params.publickey ,this.captchaId,
//                    {
//                      theme: $theme,
//                      lang: $lang
//                    }
//                  );
    }

    this.validateCaptcha = function()
    {
        var result = {};
        self.error = '';
        
        $.ajax( {
                url: self.responderUrl,
                type: 'POST',
                data: {
                    "remoteip": self.userIp,
                    "response": grecaptcha.getResponse(self.widget)
                },
                dataType: 'json',
                async: false
            } ).done( function(data)
                {
                    result = data;
                    self.error = data.error;
                } );

        if( result.result == true )
        {
             return true;
        }
        else
        {
            grecaptcha.reset();
        }
        
        return false;
    }
    
    this.getError = function()
    {
        return self.error;
    }
}

